import React from "react";

function BuildFlex() {
  return (
    <div>
      <section id="build-flex">
        <div class="container-fluid" style={{ marginBottom: "-100px" }}>
          <h1>
            Built during
            <a href="https://c2c.acmvit.in"> Hack Code2Create 2020 </a>
            <span> Built by Team Futuriste </span>
          </h1>
        </div>
      </section>
    </div>
  );
}

export default BuildFlex;
