// import React from "react";

// import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

// // Components
// import Login from "./Login.js";
// import history from "../history";
// import Home from "./Home.js";
// import Register from "./Register";

// const Routes = () => {
//   return (
//     <Router history={history}>
//       <Switch>
//         <Route exact path="/" component={Home} />
//         <Route exact path="/Login" component={Login} />
//         <Route exact path="/Register" component={Register} />
//       </Switch>
//     </Router>
//   );
// };

// export default Routes;
