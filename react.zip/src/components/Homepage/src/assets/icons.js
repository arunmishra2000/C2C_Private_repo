import home from './icons/home.svg'
import blog from './icons/blog.svg'
import resources from './icons/resources.svg'
import services from './icons/services.svg'

export default { home, blog, resources, services }
